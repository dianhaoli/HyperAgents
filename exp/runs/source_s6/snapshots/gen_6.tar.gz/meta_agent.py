# Copyright (c) Meta Platforms, Inc. and affiliates.

from agent.base_agent import AgentSystem
from agent.llm_withtools import chat_with_agent

class MetaAgent(AgentSystem):
    def forward(self, repo_path, eval_path, iterations_left=None):
        """
        A meta agent that recursively self-improves.

        Args:
            repo_path (str): The path to the repository.
            eval_path (str): The path to previously generated agents and their evaluation results.
            iterations_left (int, optional): The number of remaining iterations in which the meta agent will be invoked in future. Defaults to None.
        """
        instruction = f"Modify any part of the codebase at `{repo_path}`."
        # [experiment adaptation, see DECISIONS.md] gpt-6-luna otherwise asks for clarification and never edits.
        instruction += (
            f"\n\nThe repository's README.md describes the goal. Previously generated agents and their evaluation results are at `{eval_path}`. "
            "Work autonomously: nobody will answer questions, so do not ask for clarification. "
            "Before editing, inspect the evaluation reports and metadata for the latest generations and their parents. Compare overall scores only when the evaluations cover the same tasks, and use per-task results to distinguish persistent failures from regressions. "
            "For failed tasks, inspect available predictions and agent chat logs to find a concrete failure pattern; use the strongest comparable generation as evidence, not as proof that its approach is universally better. "
            "Make a focused change to the agent or generation mechanism that addresses the observed failure pattern. Do not edit evaluation outputs or add caches/bytecode. Run lightweight checks for your change and report when evidence is incomplete rather than claiming an untested improvement. "
            "Use the tools to inspect the code and make your changes; a response without a tool call ends the session, so only reply without one when you are done."
        )

        new_msg_history = chat_with_agent(instruction, model=self.model, msg_history=[], logging=self.log, tools_available='all')
