# Copyright (c) Meta Platforms, Inc. and affiliates.

import json
import os
import re

from agent.base_agent import AgentSystem
from agent.llm_withtools import chat_with_agent


def _generation_key(name):
    """Sort completed generation directory names in creation order."""
    if name == "gen_initial":
        return (0, 0)
    match = re.fullmatch(r"gen_(\d+)", name)
    if match:
        return (1, int(match.group(1)))
    return None


def _evaluation_summary(eval_path, limit=8):
    """Return a compact summary of completed evaluations for the meta-agent prompt."""
    if not os.path.isdir(eval_path):
        return f"No readable prior-evaluation directory found at {eval_path!r}."

    records = []
    try:
        generation_names = sorted(
            (name for name in os.listdir(eval_path) if _generation_key(name) is not None),
            key=_generation_key,
        )
    except OSError as exc:
        return f"Could not read prior-evaluation directory {eval_path!r}: {exc}"

    for generation in generation_names:
        generation_dir = os.path.join(eval_path, generation)
        if not os.path.isdir(generation_dir):
            continue
        try:
            with open(os.path.join(generation_dir, "metadata.json"), encoding="utf-8") as stream:
                metadata = json.load(stream)
        except (OSError, ValueError):
            metadata = {}
        # Do not treat skipped or staged-only runs as completed evaluation results.
        if metadata.get("run_eval") is False or metadata.get("run_full_eval") is False:
            continue

        for root, dirs, files in os.walk(generation_dir):
            dirs[:] = [name for name in dirs if name not in {".git", "__pycache__", "agent_output"}]
            if "report.json" not in files:
                continue
            report_path = os.path.join(root, "report.json")
            try:
                with open(report_path, encoding="utf-8") as stream:
                    report = json.load(stream)
            except (OSError, ValueError):
                continue
            if not isinstance(report, dict):
                continue

            record = {
                "generation": generation,
                "evaluation": os.path.relpath(root, generation_dir),
                "accuracy": report.get("overall_accuracy"),
                "inputs": report.get("total_test_inputs", report.get("total")),
                "failed_ids": report.get("question_ids_failed", []),
                "parent": metadata.get("parent_genid"),
            }
            records.append(record)

    if not records:
        return "No completed report.json evaluation results were found."

    recent = records[-limit:]
    best = max(
        (r for r in records if isinstance(r["accuracy"], (int, float))),
        key=lambda r: r["accuracy"],
        default=None,
    )
    selected = list(recent)
    if best is not None and best not in selected:
        selected.append(best)

    lines = [
        "Prior completed evaluations (accuracy comparisons are meaningful only for matching input counts):"
    ]
    for record in selected:
        failed = record["failed_ids"]
        if not isinstance(failed, list):
            failed = []
        accuracy = record["accuracy"]
        accuracy_text = f"{accuracy:.4f}" if isinstance(accuracy, (int, float)) else "unknown"
        inputs = record["inputs"] if record["inputs"] is not None else "unknown"
        line = (
            f"- {record['generation']}/{record['evaluation']}: accuracy={accuracy_text}, "
            f"inputs={inputs}, parent={record['parent']}, failures={len(failed)}"
        )
        if failed:
            line += ", failed_ids=" + ",".join(str(item) for item in failed[:12])
            if len(failed) > 12:
                line += ",..."
        lines.append(line)
    lines.append(
        "For failed task IDs, inspect the corresponding predictions.json and relevant agent code; "
        "use the observed error patterns to motivate a focused change."
    )
    return "\n".join(lines)


class MetaAgent(AgentSystem):
    def forward(self, repo_path, eval_path, iterations_left=None):
        """Inspect the repository and evaluation evidence, then improve the agent-generation system."""
        instruction = (
            f"Modify the codebase at `{repo_path}` to improve its ability to generate agents for the "
            "downstream tasks described in README.md. Work autonomously; do not ask for clarification."
        )
        instruction += "\n\n" + _evaluation_summary(eval_path)
        instruction += (
            "\n\nInspect the relevant implementation and representative failed predictions before deciding "
            "what to change. Make a focused, evidence-based improvement to the generation or improvement "
            "mechanism, preserve existing interfaces, and avoid changing evaluation/domain task files. "
            "Run relevant lightweight checks when practical. Use the available tools to make the change; "
            "only finish without a tool call after the work is complete."
        )

        return chat_with_agent(
            instruction,
            model=self.model,
            msg_history=[],
            logging=self.log,
            tools_available="all",
        )
